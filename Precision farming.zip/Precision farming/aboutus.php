 <?php
include("header.php");
?>

<style type="text/css">
<center>
body{
   background-image:url(images/14.jpg);
   background-position:center;
   background-size:cover;
   font-family:sans-serif;
   margin: auto auto;
 
}

*{
  margin: 0;
  padding: 0;
}
    
.feedbackform{
            width:700px;
           background-color:rgb(0,0,0,5);
          margin: auto auto;
          color:#FFFFFF;
           padding:10px 0px 10px 0px;
         text-align:center;
         border-radius:15px 15px 0px 0px;
}

.aboutus{
         margin:auto auto;

         }
  #aboutus{
        width:100%;
        height:50px;
}
.aboutus{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}  
</center>
</style>


<div class="aboutus">
<div class="row">
<div class="col-sm-"12">
<marquee direction=left> <h3><b>Shetkari Producer Company's Precision Farming</b></h3></marquee>
<img src="images\14.jpg" width=100% height=300px>
</div></div>
<h1 align=center>About us... </h1>
<br>
<p align=justify>
<h4><b>Shetkari prouducer company's Onion seeds product is to help you by providing all kind of information related to onion seeds and onions. It helps you to improve their productivity and profitability.It enables you to buy onion and onion seeds through online directly from sellers of Shetkari Producer Company’s onion seeds.we can help you to improve productivity.You can contact directly with the owners of Shetkari Producer Company’s onion seeds.You can purchase the products which are uploaded by the company.You will get the great quality of seed in good price. After purchasing the  seeds are  delivered at your doorstep. We will help you to gain more information about  the crop of onion seeds and we will provide a guide for the  cropcare and for using fertilizers.
</b>
</h4>


<?php
include("footer.php");
?>

<?php
include("header1.php");
?>



<div class="container-fluid">
<div class="row">
<div class="col-sm-12">
<img src="images\9.jpg" width=100% height=300px>
</div></div>
<h1 align=center><b>Our Services</b></h1>
<div class="row">
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="images/7.jpg" target="_blank">
          <img src="images/7.jpg" alt="Lights" style="width:100%">
          <div class="caption">
            <h1 align=center><p>Crop Care</p></h1>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="images/8.jpg" target="_blank">
          <img src="images/8.jpg" alt="Nature" style="width:100%">
          <div class="caption">
            <h1 align=center><p>Guidance </p></h1>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="images/4.jpg" target="_blank">
          <img src="images/4.jpg" alt="Fjords" style="width:100%">
          <div class="caption">
          <h1 align=center><p>Upload Poduct</p></h1>
          </div>
        </a>
      </div>
    </div>
    
    
</div>

<?php
include("footer.php");
?>

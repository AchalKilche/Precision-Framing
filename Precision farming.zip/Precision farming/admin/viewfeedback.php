<?php
include("header1.php");
?>

<h1 align=center>Recent Orders</h1>
 <table class="table">
    <thead>
      <tr>
        
        <th>Feedback</th>
        <th>EmailId</th>
        <th>Name</th>
      </tr>
    </thead>
    <tbody>
<?php
include("connection.php");

$rs=mysqli_query($cn,"select * from feedback");
while($a=mysqli_fetch_array($rs))
{
 extract($a);

echo "<tr><td>$Feedback</td><td>$EmailId</td><td>$Name</td></tr>";
}
?>
    </tbody>
  </table>
<?php
include("footer.php");
?>
<?php
include("header.php");
?>
<style type="text/css">



*{
  margin: 0;
  padding: 0;
}
    

.contactus{
         margin:auto auto;

         }
  #contactus{
        width:100%;
        height:50px;
}
.contactus{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}  

</style>


<div class="contactus">
<div class="row">
<div class="col-sm-"12">
<marquee direction=left> <h3><b>Shetkari Producer Company's Precision Farming</b></h3></marquee>
<img src="images\14.jpg" width=100% height=300px>
</div></div></div>
<h1 align=center>Contact us</h1>
  <p align=center> <span class="glyphicon glyphicon-envelope"><b> : precisionfarming13@gmail.com</b></span></p>
  <p align=center> <span class="glyphicon glyphicon-earphone"><b> : 9763540338 </b></span></p>



<?php
include("footer.php");
?>

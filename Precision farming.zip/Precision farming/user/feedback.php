<?php
include("header.php");
?>
<style type="text/css">

*{
  margin: 0;
  padding: 0;
}
    
.feedbackform{
            width:700px;
           background-color:rgb(0,0,0,5);
          margin: auto auto;
          color:#FFFFFF;
           padding:10px 0px 10px 0px;
         text-align:center;
         border-radius:15px 15px 0px 0px;
}

.form{
         margin:auto auto;

         }
  #name{
        width:100%;
        height:50px;
}
.name{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}  

.email{
 margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}
.feedback{
   margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}
 </style>
<div class="feedbackform">
<div class="row">
<div class="col-sm-12">
<img src="images\9.jpg" width=100% height=300px>
</div></div></div>
<h1 align=center>Give Your Feedback... </h1>

<form id=frmreg method="post" name="myForm">
  <div class="email">
    <label for="email"><h3><b>Email:</h3></label>
    <input type="email" class="form-control" id="email" placeholder="Enter your email" oninvalid="this.setCustomValidity('Please enter valid Email')" oninput="this.setCustomValidity('')" name='email' Required>
  </div>
  <div class="name">
    <label for="name"><h3><b>Name:</h3></label>
    <input type="Name" class="form-control" id="name" placeholder="Enter your name" pattern="\D+" oninvalid="this.setCustomValidity('Please enter valid name')" oninput="this.setCustomValidity('')" name='nm' Required>
  </div>
<div class="feedback">
    <label for="text"><h3><b>Feedback:</h3></label>
    <textarea class="form-control" id="feedback" placeholder="Enter Your Feedback" required name="fdbk">
</textarea>
  </div>

 <center><h1>
<button type="submit" class="btn btn-success" id="btnsub" name=btnsub><h4>Submit</h4></button>
</h1></center>
</form>


<?php
include("footer.php");
if(isset($_POST['btnsub']))
{
extract($_POST);
include("connection.php");
$q="insert into feedback values('$nm','$email','$fdbk')";
mysqli_query($cn,$q);
mysqli_close($cn);
echo"<script>alert('Feedback Submitted');window.location='index.php'</script>";
}

?>